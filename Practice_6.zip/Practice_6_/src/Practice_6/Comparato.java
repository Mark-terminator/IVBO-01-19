package Practice_6;

public interface Comparato {
    public boolean compareTo(Student student1, Student student2);
}
