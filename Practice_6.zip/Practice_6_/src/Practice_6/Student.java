package Practice_6;

public class Student {
    private int ball;

    public Student(int ball){
        this.ball = ball;
    }
    public int getBall() {
        return ball;
    }

    public void setBall(int ball) {
        this.ball = ball;
    }
}
